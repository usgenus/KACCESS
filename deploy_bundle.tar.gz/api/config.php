<?php
/**
 * Global CMS Database, Persistent Storage & Cloud Configuration
 */

// 1. Supabase Project Settings
define('SUPABASE_URL', 'https://hjswqohhrrgclosqsikw.supabase.co');
define('SUPABASE_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imhqc3dxb2hocnJnY2xvc3FzaWt3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODYzNjMxMTMsImV4cCI6MjEwMTkzOTExM30.cIaGtw9CSLvPib5V6WbB7nM5_AnGg0Iz_rd2ccO52UI');

// 3. Gemini AI Translation API Key (get free key at https://aistudio.google.com)
// Load securely from environment variable to prevent public exposure
define('GEMINI_API_KEY', getenv('GEMINI_API_KEY') ?: '');

// 2. Resolve Hostinger Persistent Host Space (Outside public_html so static deployments NEVER wipe data)
function get_persistent_root() {
    $candidates = [
        dirname(__DIR__, 3) . '/persistent_storage', // e.g. /domains/njaccessportal.com/persistent_storage
        dirname(__DIR__, 2) . '/persistent_storage', // e.g. for root deployment
        dirname(__DIR__, 4) . '/cms_persistent_data',
        __DIR__ . '/../data'
    ];
    foreach ($candidates as $dir) {
        if (!is_dir($dir)) {
            @mkdir($dir, 0777, true);
            @chmod($dir, 0777);
        }
        if (is_dir($dir) && is_writable($dir)) {
            return realpath($dir) ?: $dir;
        }
    }
    return realpath(__DIR__ . '/../data') ?: (__DIR__ . '/../data');
}

$persistentRoot = get_persistent_root();
define('PERSISTENT_ROOT', $persistentRoot);
define('PERSISTENT_DATA_FILE', PERSISTENT_ROOT . '/content.json');
define('PERSISTENT_MEDIA_STORE', PERSISTENT_ROOT . '/media_store.json');
define('PERSISTENT_IMAGES_DIR', PERSISTENT_ROOT . '/uploads/images');
define('PERSISTENT_VIDEOS_DIR', PERSISTENT_ROOT . '/uploads/videos');
define('PERSISTENT_AUDIO_DIR', PERSISTENT_ROOT . '/uploads/audio');

// Ensure persistent folders exist
if (!is_dir(PERSISTENT_IMAGES_DIR)) { @mkdir(PERSISTENT_IMAGES_DIR, 0777, true); @chmod(PERSISTENT_IMAGES_DIR, 0777); }
if (!is_dir(PERSISTENT_VIDEOS_DIR)) { @mkdir(PERSISTENT_VIDEOS_DIR, 0777, true); @chmod(PERSISTENT_VIDEOS_DIR, 0777); }
if (!is_dir(PERSISTENT_AUDIO_DIR)) { @mkdir(PERSISTENT_AUDIO_DIR, 0777, true); @chmod(PERSISTENT_AUDIO_DIR, 0777); }

// Local public_html mirrors
define('DATA_FILE', __DIR__ . '/../data/content.json');
define('LOCAL_MEDIA_STORE', __DIR__ . '/../data/media_store.json');
define('LOCAL_IMAGES_DIR', __DIR__ . '/../uploads/images');
define('LOCAL_VIDEOS_DIR', __DIR__ . '/../uploads/videos');
define('LOCAL_AUDIO_DIR', __DIR__ . '/../uploads/audio');

if (!is_dir(LOCAL_IMAGES_DIR)) { @mkdir(LOCAL_IMAGES_DIR, 0777, true); @chmod(LOCAL_IMAGES_DIR, 0777); }
if (!is_dir(LOCAL_VIDEOS_DIR)) { @mkdir(LOCAL_VIDEOS_DIR, 0777, true); @chmod(LOCAL_VIDEOS_DIR, 0777); }
if (!is_dir(LOCAL_AUDIO_DIR)) { @mkdir(LOCAL_AUDIO_DIR, 0777, true); @chmod(LOCAL_AUDIO_DIR, 0777); }
