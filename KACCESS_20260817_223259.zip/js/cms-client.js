/**
 * NJ Access Center - Dynamic CMS Client Loader (v2.1)
 * Powers Gallery Billboard, Medical Video News, and Dynamic News feeds.
 * Resilient against SPA / React hydration and browser cache.
 */

(function () {
  'use strict';

  // State
  let billboards = [];
  let currentBillboardIndex = 0;
  let billboardTimer = null;

  let videos = [];
  let currentVideo = null;
  let activeVideoCategory = '전체';
  let stateVideoCategories = [];

  let posts = [];

  // Multi-stage loader to guarantee injection even after async Next.js hydration
  function runInit() {
    initBillboards();
    initMedicalVideos();
    initNewsFeeds();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', runInit);
  } else {
    runInit();
  }

  window.addEventListener('load', runInit);
  setTimeout(runInit, 300);
  setTimeout(runInit, 800);
  setTimeout(runInit, 1800);
  setTimeout(runInit, 3500);

  // =========================================================
  // 1. GALLERY BILLBOARD SYSTEM
  // =========================================================
  async function initBillboards() {
    const container = document.getElementById('gallery-billboard-container');
    if (!container) return;

    if (billboards.length > 0) {
      renderBillboardShowcase();
      return;
    }

    try {
      const res = await fetch(`/api/billboards.php?active_only=1&_t=${Date.now()}`, {
        cache: 'no-store'
      });
      const data = await res.json();
      if (data.success && data.data && data.data.length > 0) {
        billboards = data.data;
        renderBillboardShowcase();
      }
    } catch (e) {
      console.warn('Billboard CMS loading error:', e);
    }
  }

  function renderBillboardShowcase() {
    const container = document.getElementById('gallery-billboard-container');
    if (!container || billboards.length === 0) return;

    const b = billboards[currentBillboardIndex] || billboards[0];
    const isVideo = b.mediaType === 'video' || (b.mediaUrl && (b.mediaUrl.endsWith('.mp4') || b.mediaUrl.endsWith('.webm')));

    container.innerHTML = `
      <div class="relative w-full h-[380px] sm:h-[460px] md:h-[520px] lg:h-[560px] rounded-3xl overflow-hidden shadow-2xl bg-slate-950 border border-slate-200/80 select-none group"
        onmouseenter="window.cmsPauseBillboard()" onmouseleave="window.cmsResumeBillboard()">
        
        <!-- Full-bleed Media Stage -->
        <div class="w-full h-full relative overflow-hidden">
          ${isVideo ? `
            <video src="${b.mediaUrl}" class="w-full h-full object-cover" autoplay muted loop playsinline></video>
          ` : `
            <img src="${b.mediaUrl || 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=1800&q=85&auto=format'}" 
              alt="${escapeHtml(b.title)}" 
              class="w-full h-full object-cover transform scale-100 group-hover:scale-102 transition-transform duration-1000 ease-out">
          `}
          <!-- Gradient Vignette for Text Legibility -->
          <div class="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/25 to-black/15 pointer-events-none"></div>
        </div>

        <!-- Left Chevron Navigation Arrow (Matching user design) -->
        <button onclick="window.cmsPrevBillboard()" 
          class="absolute left-3 sm:left-6 top-1/2 -translate-y-1/2 w-11 h-11 sm:w-14 sm:h-14 rounded-full bg-black/35 hover:bg-red-600 text-white backdrop-blur-md border border-white/20 flex items-center justify-center text-2xl sm:text-3xl transition-all duration-300 z-20 hover:scale-110 shadow-2xl cursor-pointer"
          aria-label="Previous Slide">
          ‹
        </button>

        <!-- Right Chevron Navigation Arrow (Matching user design) -->
        <button onclick="window.cmsNextBillboard()" 
          class="absolute right-3 sm:right-6 top-1/2 -translate-y-1/2 w-11 h-11 sm:w-14 sm:h-14 rounded-full bg-black/35 hover:bg-red-600 text-white backdrop-blur-md border border-white/20 flex items-center justify-center text-2xl sm:text-3xl transition-all duration-300 z-20 hover:scale-110 shadow-2xl cursor-pointer"
          aria-label="Next Slide">
          ›
        </button>

        <!-- Bottom Content Overlay -->
        <div class="absolute bottom-0 left-0 right-0 p-6 sm:p-10 z-10 text-white flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div class="max-w-3xl space-y-2.5">
            <div class="flex items-center gap-2.5">
              <span class="bg-gradient-to-r from-red-600 to-red-700 text-white text-[11px] font-extrabold px-3.5 py-1 rounded-full uppercase tracking-wider shadow-md">
                ${escapeHtml(b.category || 'SPECIAL CAMPAIGN')}
              </span>
              <span class="text-xs font-mono text-white/80 bg-black/40 px-2.5 py-0.5 rounded-full backdrop-blur-xs border border-white/15">
                ${currentBillboardIndex + 1} / ${billboards.length}
              </span>
            </div>

            <h3 class="font-extrabold text-2xl sm:text-3xl lg:text-4xl text-white tracking-tight leading-snug drop-shadow-md">
              ${escapeHtml(b.title)}
            </h3>

            <p class="text-white/85 text-xs sm:text-sm sm:leading-relaxed max-w-2xl font-normal drop-shadow">
              ${escapeHtml(b.subtitle || '')}
            </p>
          </div>

          <div class="flex items-center gap-3 shrink-0">
            <a href="${b.linkUrl || '/about#contact'}" class="inline-flex items-center gap-2 bg-gradient-to-r from-red-600 to-brand-blue hover:from-red-500 hover:to-blue-600 text-white font-extrabold text-sm px-6 py-3.5 rounded-2xl shadow-2xl hover:scale-105 transition-all">
              <span>${escapeHtml(b.linkText || '자세히 보기')}</span>
              <span>→</span>
            </a>
          </div>
        </div>

        <!-- Center Bottom Dots Indicator (Matching user design) -->
        <div class="absolute bottom-3 sm:bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-2 z-20">
          ${billboards.map((item, idx) => `
            <button onclick="window.cmsSelectBillboard(${idx})" 
              class="h-2 rounded-full transition-all duration-300 cursor-pointer ${
                idx === currentBillboardIndex 
                  ? 'w-8 bg-white shadow-lg ring-2 ring-white/50' 
                  : 'w-2.5 bg-white/40 hover:bg-white/80'
              }" 
              aria-label="Billboard slide ${idx + 1}">
            </button>
          `).join('')}
        </div>

      </div>
    `;

    resetBillboardTimer();
  }

  function resetBillboardTimer() {
    if (billboardTimer) clearInterval(billboardTimer);
    if (billboards.length > 1) {
      billboardTimer = setInterval(() => {
        window.cmsNextBillboard();
      }, 4000); // Auto-advance every 4 seconds as requested
    }
  }

  window.cmsPauseBillboard = function () {
    if (billboardTimer) clearInterval(billboardTimer);
  };

  window.cmsResumeBillboard = function () {
    resetBillboardTimer();
  };

  window.cmsSelectBillboard = function (idx) {
    currentBillboardIndex = idx;
    renderBillboardShowcase();
  };

  window.cmsNextBillboard = function () {
    if (billboards.length <= 1) return;
    currentBillboardIndex = (currentBillboardIndex + 1) % billboards.length;
    renderBillboardShowcase();
  };

  window.cmsPrevBillboard = function () {
    if (billboards.length <= 1) return;
    currentBillboardIndex = (currentBillboardIndex - 1 + billboards.length) % billboards.length;
    renderBillboardShowcase();
  };


  // =========================================================
  // 2. MEDICAL VIDEO NEWS ('🎬 의학비디오뉴스')
  // =========================================================
  async function initMedicalVideos() {
    const section = document.getElementById('medical-videos-section');
    if (!section) return;

    if (videos.length > 0) {
      renderVideoCategories(stateVideoCategories);
      renderVideoPlayerAndList();
      return;
    }

    try {
      const res = await fetch(`/api/videos.php?active_only=1&_t=${Date.now()}`, {
        cache: 'no-store'
      });
      const data = await res.json();
      if (data.success && data.data && data.data.length > 0) {
        videos = data.data;
        currentVideo = videos[0];
        stateVideoCategories = data.categories || [];
        renderVideoCategories(stateVideoCategories);
        renderVideoPlayerAndList();
      }
    } catch (e) {
      console.warn('Medical videos CMS loading error:', e);
    }
  }

  function renderVideoCategories(categories) {
    const catContainer = document.getElementById('medical-videos-categories');
    if (!catContainer) return;

    const allCats = ['전체', ...categories.filter(c => c !== '전체')];
    catContainer.innerHTML = allCats.map(cat => `
      <button onclick="window.cmsSetVideoCat('${escapeHtml(cat)}')" 
        class="text-xs font-semibold px-4 py-2 rounded-full transition-all whitespace-nowrap ${
          activeVideoCategory === cat 
            ? 'bg-red-600 text-white shadow-sm font-semibold' 
            : 'bg-white border border-slate-200/80 text-slate-700 hover:bg-slate-100 hover:text-slate-900 font-medium'
        }">
        ${escapeHtml(cat)}
      </button>
    `).join('');
  }

  function renderVideoPlayerAndList() {
    const playerBox = document.getElementById('medical-video-player-box');
    const infoBox = document.getElementById('medical-video-info-box');
    const listBox = document.getElementById('medical-videos-playlist');
    const countBadge = document.getElementById('medical-videos-count-badge');

    if (!currentVideo) return;

    // Filtered list
    const filtered = activeVideoCategory === '전체' 
      ? videos 
      : videos.filter(v => v.category === activeVideoCategory);

    if (countBadge) {
      countBadge.textContent = `${filtered.length}개 영상`;
    }

    // Render Main Video Player
    if (playerBox) {
      if (currentVideo.videoUrl && (currentVideo.videoUrl.endsWith('.mp4') || currentVideo.videoUrl.endsWith('.webm'))) {
        playerBox.innerHTML = `
          <video src="${currentVideo.videoUrl}" controls autoplay class="w-full h-full object-cover bg-black rounded-2xl"></video>
        `;
      } else if (currentVideo.youtubeId) {
        playerBox.innerHTML = `
          <iframe src="https://www.youtube.com/embed/${currentVideo.youtubeId}?autoplay=1&rel=0" 
            title="${escapeHtml(currentVideo.title)}" 
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
            allowfullscreen 
            class="w-full h-full border-0 rounded-2xl"></iframe>
        `;
      } else {
        playerBox.innerHTML = `
          <div class="relative w-full h-full cursor-pointer group">
            <img src="${currentVideo.thumbnail || 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&q=80'}" alt="${escapeHtml(currentVideo.title)}" class="object-cover w-full h-full group-hover:scale-105 transition-transform duration-500">
            <div class="absolute inset-0 bg-gradient-to-t from-slate-950/40 via-transparent to-transparent"></div>
            <div class="absolute inset-0 flex items-center justify-center">
              <div class="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-white text-red-600 flex items-center justify-center text-2xl sm:text-3xl shadow-2xl group-hover:scale-110 group-hover:bg-red-600 group-hover:text-white transition-all ring-4 ring-red-500/30">▶</div>
            </div>
            <div class="absolute bottom-4 left-4 right-4 flex items-end justify-between">
              <span class="bg-red-600 text-white text-xs font-bold px-3.5 py-1 rounded-full shadow-sm">${escapeHtml(currentVideo.category)}</span>
              <span class="bg-white/95 backdrop-blur-sm text-slate-900 text-xs font-mono font-semibold px-2.5 py-1 rounded-md border border-slate-200/80 shadow-sm">⏱ ${escapeHtml(currentVideo.duration || '00:00')}</span>
            </div>
          </div>
        `;
      }
    }

    // Render Main Video Info Box
    if (infoBox) {
      infoBox.innerHTML = `
        <div class="flex items-center gap-3 text-xs text-slate-500">
          <span class="font-bold text-brand-blue">${escapeHtml(currentVideo.doctor || '의학 리포트')}</span>
          <span>·</span>
          <span>${escapeHtml(currentVideo.hospital || 'Englewood Health Center for Korean Health')}</span>
          <span>·</span>
          <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-red-50 text-red-600 font-semibold text-xs border border-red-100">
            👁️ ${escapeHtml(currentVideo.views || '10만회')}
          </span>
        </div>
        <h3 class="font-extrabold text-xl sm:text-2xl text-slate-900 leading-snug tracking-tight">
          ${escapeHtml(currentVideo.title)}
        </h3>
        <p class="text-xs sm:text-sm text-slate-600 leading-relaxed pt-1">
          ${escapeHtml(currentVideo.summary || '')}
        </p>
      `;
    }

    // Render Playlist
    if (listBox) {
      listBox.innerHTML = filtered.map(v => {
        const isSelected = v.id === currentVideo.id;
        const thumb = v.thumbnail || (v.youtubeId ? `https://img.youtube.com/vi/${v.youtubeId}/hqdefault.jpg` : 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=400&q=80');
        return `
          <div onclick="window.cmsSelectVideo('${v.id}')" 
            class="group p-3 rounded-2xl border transition-all cursor-pointer flex gap-3.5 items-center ${
              isSelected 
                ? 'bg-red-50/80 border-red-200/90 ring-1 ring-red-400/30 shadow-sm' 
                : 'bg-white border-slate-200/80 hover:bg-slate-50/80 hover:border-slate-300 shadow-xs hover:shadow-sm'
            }">
            <div class="relative w-28 h-18 rounded-xl overflow-hidden shrink-0 bg-slate-100 border border-slate-200/80 shadow-xs">
              <img src="${thumb}" 
                alt="${escapeHtml(v.title)}" class="object-cover group-hover:scale-105 transition-transform duration-300 w-full h-full">
              <div class="absolute inset-0 flex items-center justify-center bg-black/10 group-hover:bg-black/20 transition-colors">
                <span class="w-7 h-7 rounded-full flex items-center justify-center text-xs ${
                  isSelected ? 'bg-red-600 text-white shadow-md' : 'bg-white/95 text-slate-700 group-hover:bg-red-600 group-hover:text-white shadow-sm'
                } transition-colors">▶</span>
              </div>
              <span class="absolute bottom-1 right-1 bg-white/90 backdrop-blur-sm text-[10px] text-slate-800 font-semibold px-1.5 py-0.5 rounded font-mono border border-slate-200/60 shadow-xs">${escapeHtml(v.duration || '00:00')}</span>
            </div>
            <div class="flex-1 min-w-0">
              <span class="text-[10px] font-bold text-brand-blue uppercase tracking-wider block mb-0.5">${escapeHtml(v.category)}</span>
              <h4 class="font-bold text-xs sm:text-sm leading-snug line-clamp-2 transition-colors ${
                isSelected ? 'text-red-600' : 'text-slate-900 group-hover:text-red-600'
              }">${escapeHtml(v.title)}</h4>
              <div class="flex items-center gap-2 text-[11px] text-slate-500 mt-1.5">
                <span class="truncate">${escapeHtml(v.doctor || '의학 전문의')}</span>
                <span>·</span>
                <span class="text-slate-700 font-semibold">${escapeHtml(v.views || '조회수')}</span>
              </div>
            </div>
          </div>
        `;
      }).join('');
    }
  }

  window.cmsSetVideoCat = function (cat) {
    activeVideoCategory = cat;
    renderVideoCategories(stateVideoCategories);
    renderVideoPlayerAndList();
  };

  window.cmsSelectVideo = function (id) {
    const v = videos.find(item => item.id === id);
    if (v) {
      currentVideo = v;
      renderVideoPlayerAndList();
    }
  };


  // =========================================================
  // 3. DYNAMIC NEWS & BLOG FEEDS
  // =========================================================
  async function initNewsFeeds() {
    if (posts.length > 0) {
      updateHomepageNewsings();
      updateBlogListings();
      return;
    }

    try {
      const res = await fetch(`/api/posts.php?_t=${Date.now()}`, {
        cache: 'no-store'
      });
      const data = await res.json();
      if (data.success && data.data && data.data.length > 0) {
        posts = data.data;
        updateHomepageNewsings();
        updateBlogListings();
      }
    } catch (e) {
      console.warn('News CMS loading error:', e);
    }
  }

  function updateHomepageNewsings() {
    if (!posts || posts.length === 0) return;

    // Determine Top Story: either explicitly marked isTopStory or first post in database
    const top = posts.find(p => p.isTopStory) || posts[0];
    const otherPosts = posts.filter(p => p.id !== top.id);

    // 1. Target Top Story Container (by ID or fallback querySelector)
    const topStoryBox = document.getElementById('homepage-top-story-box') 
      || document.querySelector('main section .grid.grid-cols-1.lg\\:grid-cols-12 > div:first-child');
    
    if (topStoryBox) {
      const summaryList = (top.summaryPoints && top.summaryPoints.length > 0)
        ? top.summaryPoints
        : ['공식 당국 승인 안전 가이드라인 적용 및 자진 리콜 조치', '뉴저지 거주 한인 대상 한국어 무료 상담 창구 운영', '처방약 복용 시 주의 사항 및 환불·교환 절차 안내'];

      topStoryBox.innerHTML = `
        <a class="group block" href="/blog/${top.slug || top.id}">
          <div class="flex items-center gap-2 mb-3">
            <span class="w-2.5 h-2.5 rounded-full bg-red-600"></span>
            <span class="text-xs font-bold text-red-600 uppercase tracking-widest">${escapeHtml(top.category || '주요 뉴스')}</span>
            <span class="text-xs text-gray-400">·</span>
            <span class="text-xs text-gray-500">${escapeHtml(top.date || '2026년')}</span>
          </div>
          <h1 class="font-sans font-extrabold text-2xl sm:text-4xl text-gray-950 leading-tight mb-4 tracking-tight group-hover:text-brand-blue transition-colors">
            ${escapeHtml(top.title)}
          </h1>
          <div class="relative h-64 sm:h-96 w-full rounded-xl overflow-hidden mb-5 bg-gray-100 shadow-sm">
            <img src="${top.coverImage || 'https://images.unsplash.com/photo-1628771065117-74ccb5690668?w=1200&q=80'}" 
              alt="${escapeHtml(top.title)}" 
              class="object-cover group-hover:scale-102 transition-transform duration-500 w-full h-full">
          </div>
          <p class="text-gray-700 text-sm sm:text-base leading-relaxed mb-5">
            ${escapeHtml(top.excerpt || '')}
          </p>
        </a>
        <div class="bg-gray-50 rounded-xl p-4 border border-gray-200/80 mb-5">
          <p class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">핵심 요약</p>
          <ul class="space-y-1.5 text-xs sm:text-sm text-gray-800 font-medium">
            ${summaryList.slice(0, 3).map(pt => `
              <li class="flex items-start gap-2">
                <span class="text-red-600 font-bold">•</span>
                <span>${escapeHtml(pt)}</span>
              </li>
            `).join('')}
          </ul>
        </div>
        <div class="flex items-center justify-between text-xs text-gray-500 pt-3 border-t border-gray-100">
          <div class="flex items-center gap-2">
            <span class="font-bold text-gray-900">${escapeHtml(top.author || '편집부')}</span>
            <span>·</span>
            <span>⏱ ${escapeHtml(top.readTime || '3분')} 읽기</span>
          </div>
          <span class="text-red-600 font-semibold text-[11px] uppercase tracking-wider">TOP STORY</span>
        </div>
      `;
    }

    // 2. Target Latest News List (items 1 to 4 of remaining posts)
    const latestBox = document.getElementById('homepage-latest-news-box') 
      || document.querySelector('main section .grid.grid-cols-1.lg\\:grid-cols-12 > div:last-child .divide-y');
    
    if (latestBox && otherPosts.length > 0) {
      const latestItems = otherPosts.slice(0, 4);
      latestBox.innerHTML = latestItems.map(p => `
        <a class="group py-3.5 first:pt-0 last:pb-0 flex gap-4 items-start" href="/blog/${p.slug || p.id}">
          <div class="flex-1 min-w-0">
            <span class="text-[11px] font-bold text-brand-blue uppercase tracking-wide block mb-1">${escapeHtml(p.category || '뉴스')}</span>
            <h3 class="font-bold text-sm sm:text-base text-gray-900 leading-snug line-clamp-2 group-hover:text-brand-blue transition-colors">
              ${escapeHtml(p.title)}
            </h3>
            <div class="flex items-center gap-2 text-[11px] text-gray-400 mt-2">
              <span>${escapeHtml(p.date || '')}</span>
              <span>·</span>
              <span>${escapeHtml(p.readTime || '3분')}</span>
            </div>
          </div>
          <div class="relative w-20 h-20 sm:w-24 sm:h-24 rounded-lg overflow-hidden shrink-0 bg-gray-100 border border-gray-200">
            <img src="${p.coverImage || 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=400&q=80'}" 
              alt="${escapeHtml(p.title)}" 
              class="object-cover group-hover:scale-105 transition-transform w-full h-full">
          </div>
        </a>
      `).join('');
    }

    // 3. Policy & Medicare Reports 4-card Grid
    const reportsGrid = document.getElementById('homepage-reports-grid')
      || document.querySelector('main section:nth-of-type(2) .grid.grid-cols-1.sm\\:grid-cols-2.lg\\:grid-cols-4');
    
    if (reportsGrid && otherPosts.length > 4) {
      const reportItems = otherPosts.slice(4, 8);
      reportsGrid.innerHTML = reportItems.map(p => `
        <a class="group card-hover" href="/blog/${p.slug || p.id}">
          <article class="bg-white rounded-2xl p-4 border border-gray-200/90 h-full flex flex-col justify-between shadow-sm">
            <div>
              <div class="relative h-40 w-full rounded-xl overflow-hidden mb-3 bg-gray-100">
                <img src="${p.coverImage || 'https://images.unsplash.com/photo-1541781774459-bb2af2f05b55?w=800&q=80'}" 
                  alt="${escapeHtml(p.title)}" 
                  class="object-cover group-hover:scale-105 transition-transform duration-500 w-full h-full">
              </div>
              <span class="text-[11px] font-bold text-red-600 uppercase tracking-wider block mb-1">${escapeHtml(p.category || '리포트')}</span>
              <h3 class="font-bold text-base text-gray-900 leading-snug line-clamp-2 mb-2 group-hover:text-brand-blue transition-colors">
                ${escapeHtml(p.title)}
              </h3>
              <p class="text-xs text-gray-600 line-clamp-2 leading-relaxed mb-4">
                ${escapeHtml(p.excerpt || '')}
              </p>
            </div>
            <div class="flex items-center justify-between text-[11px] text-gray-400 pt-3 border-t border-gray-100">
              <span>${escapeHtml(p.date || '')}</span>
              <span>⏱ ${escapeHtml(p.readTime || '3분')}</span>
            </div>
          </article>
        </a>
      `).join('');
    }
  }

  function updateBlogListings() {
    const blogContainer = document.getElementById('cms-blog-posts-grid')
      || document.querySelector('main .grid.grid-cols-1.sm\\:grid-cols-2.lg\\:grid-cols-3')
      || document.querySelector('.grid.grid-cols-1.sm\\:grid-cols-2');
    
    if (blogContainer) {
      blogContainer.innerHTML = posts.map(p => `
        <a class="group card-hover" href="/blog/${p.slug || p.id}">
          <article class="bg-white rounded-2xl overflow-hidden border border-brand-border h-full flex flex-col shadow-sm">
            <div class="relative h-52 overflow-hidden bg-gray-100">
              <img src="${p.coverImage || 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=800&q=80'}" 
                alt="${escapeHtml(p.title)}" class="object-cover w-full h-full group-hover:scale-105 transition-transform duration-500">
              <div class="absolute top-3 left-3">
                <span class="tag-pill bg-brand-blue text-white font-bold text-xs px-3 py-1 rounded-full shadow">${escapeHtml(p.category || '건강 뉴스')}</span>
              </div>
            </div>
            <div class="p-6 flex flex-col flex-1">
              <div class="flex items-center gap-3 text-xs font-sans text-brand-muted mb-3">
                <span>${escapeHtml(p.date || '2026.08')}</span>
                <span>·</span>
                <span>⏱ ${escapeHtml(p.readTime || '3분')} 읽기</span>
                <span>·</span>
                <span>${escapeHtml(p.author || '편집부')}</span>
              </div>
              <h2 class="font-serif text-xl text-brand-dark leading-snug mb-3 line-clamp-2 group-hover:text-brand-blue transition-colors duration-200">${escapeHtml(p.title)}</h2>
              <p class="text-sm font-sans text-brand-muted leading-relaxed line-clamp-3 flex-1">${escapeHtml(p.excerpt || '')}</p>
              <div class="mt-5 flex items-center gap-1 text-sm font-sans font-medium text-brand-blue">
                기사 읽기 <span class="group-hover:translate-x-1 transition-transform inline-block">→</span>
              </div>
            </div>
          </article>
        </a>
      `).join('');
    }
  }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

})();
