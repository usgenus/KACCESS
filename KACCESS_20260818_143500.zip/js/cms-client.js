/**
 * Healthcare Access Portal - Dynamic CMS Client Loader (v3.0.0)
 * Ultra High-Performance Interactive Controller
 * - Edge-to-edge 1920x566 Panoramic Billboard Slider with Auto-Play & Navigation
 * - Medical Video News Player & Categorized 4-Video Playlist with Pagination
 * - Real-Time Instant Blog Live Search & Category Filtering
 * - Mobile Navigation Menu Toggle
 */

(function () {
  'use strict';

  // 1. Mobile Menu Toggle
  function initMobileMenu() {
    const btn = document.getElementById('mobile-menu-btn');
    const menu = document.getElementById('mobile-menu-dropdown');
    if (!btn || !menu || btn.dataset.bound) return;

    btn.dataset.bound = '1';
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      const isOpen = menu.classList.contains('max-h-96');
      if (isOpen) {
        menu.classList.remove('max-h-96', 'opacity-100');
        menu.classList.add('max-h-0', 'opacity-0');
      } else {
        menu.classList.remove('max-h-0', 'opacity-0');
        menu.classList.add('max-h-96', 'opacity-100');
      }
    });
  }

  // 2. Global State for Billboards, Videos, and Posts
  let billboards = [];
  try { billboards = JSON.parse(sessionStorage.getItem('njap_billboards') || '[]'); } catch(e) {}
  let currentBillboardIndex = 0;
  let billboardTimer = null;

  let videos = [];
  try { videos = JSON.parse(sessionStorage.getItem('njap_videos') || '[]'); } catch(e) {}
  let currentVideo = null;
  let activeVideoCategory = '전체';
  const VIDEOS_PER_PAGE = 4;
  let currentVideoPage = 1;

  let posts = [];
  try { posts = JSON.parse(sessionStorage.getItem('njap_posts') || '[]'); } catch(e) {}
  let blogActiveCategory = '전체';
  let blogSearchQuery = '';

  // ---------------------------------------------------------
  // 3. 1920x566 PANORAMIC BILLBOARD SYSTEM
  // ---------------------------------------------------------
  async function initBillboards() {
    try {
      const res = await fetch(`/api/billboards.php?active_only=1&_t=${Date.now()}`);
      const data = await res.json();
      if (data.success && data.data && data.data.length > 0) {
        billboards = data.data;
        try { sessionStorage.setItem('njap_billboards', JSON.stringify(billboards)); } catch(e) {}
      }
    } catch (e) {}
    startBillboardTimer();
  }

  function renderBillboardShowcase() {
    const container = document.getElementById('gallery-billboard-container');
    if (!container || billboards.length === 0) return;

    const b = billboards[currentBillboardIndex] || billboards[0];
    const isVideo = b.mediaType === 'video' || (b.mediaUrl && (b.mediaUrl.endsWith('.mp4') || b.mediaUrl.endsWith('.webm')));
    const targetLink = b.linkUrl || '/about#contact';

    container.innerHTML = `
      <div class="relative w-full overflow-hidden bg-slate-950 select-none group"
        style="aspect-ratio: 1920 / 566; width: 100%; max-height: 480px;"
        onmouseenter="window.cmsPauseBillboard()" onmouseleave="window.cmsResumeBillboard()">
        
        <a href="${targetLink}" class="block relative w-full h-full cursor-pointer" title="${escapeHtml(b.title)}">
          <div class="w-full h-full relative overflow-hidden">
            ${isVideo ? `
              <video src="${b.mediaUrl}" class="w-full h-full object-cover" autoplay muted loop playsinline></video>
            ` : `
              <img src="${b.mediaUrl || 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=2000&q=85&auto=format'}" 
                alt="${escapeHtml(b.title)}" 
                class="w-full h-full object-cover transform scale-100 group-hover:scale-103 transition-transform duration-1000 ease-out">
            `}
            <div class="absolute inset-0 bg-gradient-to-t from-black/95 via-black/40 to-black/15 pointer-events-none"></div>
            <div class="absolute inset-0 bg-gradient-to-r from-black/75 via-transparent to-black/25 pointer-events-none"></div>
          </div>

          <div class="absolute inset-0 flex items-end">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full pb-4 sm:pb-6 flex items-end justify-between gap-4">
              <div class="max-w-3xl space-y-1 sm:space-y-2">
                <div class="flex items-center gap-2">
                  <span class="bg-red-600 text-white text-[10px] sm:text-xs font-extrabold px-3 py-0.5 sm:py-1 rounded-full uppercase tracking-wider shadow">
                    ${escapeHtml(b.category || 'SPECIAL CAMPAIGN')}
                  </span>
                  <span class="text-xs font-mono text-white/80 bg-black/60 px-2.5 py-0.5 rounded-full border border-white/15">
                    ${currentBillboardIndex + 1} / ${billboards.length}
                  </span>
                </div>
                <h3 class="font-extrabold text-base sm:text-2xl md:text-3xl text-white tracking-tight leading-snug drop-shadow-md group-hover:text-blue-300 transition-colors line-clamp-1">
                  ${escapeHtml(b.title)}
                </h3>
                <p class="text-white/85 text-xs sm:text-sm line-clamp-1 max-w-2xl font-normal drop-shadow hidden sm:block">
                  ${escapeHtml(b.subtitle || '')}
                </p>
              </div>

              <div class="flex items-center gap-2 shrink-0">
                <span class="inline-flex items-center gap-1.5 bg-gradient-to-r from-red-600 to-brand-blue text-white font-extrabold text-xs sm:text-sm px-4 py-2 sm:px-5 sm:py-2.5 rounded-xl shadow-xl">
                  <span>${escapeHtml(b.linkText || '자세히 보기')}</span>
                  <span>→</span>
                </span>
              </div>
            </div>
          </div>
        </a>

        <button onclick="event.stopPropagation(); event.preventDefault(); window.cmsPrevBillboard();" 
          class="absolute left-4 sm:left-8 top-1/2 -translate-y-1/2 w-9 h-9 sm:w-12 sm:h-12 rounded-full bg-black/50 hover:bg-red-600 text-white backdrop-blur-md border border-white/20 flex items-center justify-center text-xl sm:text-3xl transition-all duration-200 z-20 hover:scale-110 shadow-2xl cursor-pointer"
          aria-label="Previous Slide">
          ‹
        </button>

        <button onclick="event.stopPropagation(); event.preventDefault(); window.cmsNextBillboard();" 
          class="absolute right-4 sm:right-8 top-1/2 -translate-y-1/2 w-9 h-9 sm:w-12 sm:h-12 rounded-full bg-black/50 hover:bg-red-600 text-white backdrop-blur-md border border-white/20 flex items-center justify-center text-xl sm:text-3xl transition-all duration-200 z-20 hover:scale-110 shadow-2xl cursor-pointer"
          aria-label="Next Slide">
          ›
        </button>

        <div class="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-2 z-20">
          ${billboards.map((_, i) => `
            <button onclick="event.stopPropagation(); event.preventDefault(); window.cmsGoBillboard(${i});"
              class="transition-all duration-300 ${
                i === currentBillboardIndex 
                  ? 'w-6 h-1.5 sm:w-8 sm:h-2 bg-white rounded-full shadow-lg ring-1 ring-white/50' 
                  : 'w-2 h-1.5 sm:w-2.5 sm:h-2 bg-white/40 hover:bg-white/80 rounded-full'
              }"
              aria-label="Go to slide ${i + 1}">
            </button>
          `).join('')}
        </div>
      </div>
    `;
    startBillboardTimer();
  }

  function startBillboardTimer() {
    if (billboardTimer) clearInterval(billboardTimer);
    if (billboards.length <= 1) return;
    billboardTimer = setInterval(() => {
      currentBillboardIndex = (currentBillboardIndex + 1) % billboards.length;
      renderBillboardShowcase();
    }, 6000);
  }

  window.cmsNextBillboard = function () {
    if (billboards.length <= 1) return;
    currentBillboardIndex = (currentBillboardIndex + 1) % billboards.length;
    renderBillboardShowcase();
  };

  window.cmsPrevBillboard = function () {
    if (billboards.length <= 1) return;
    currentBillboardIndex = (currentBillboardIndex - 1 + billboards.length) % billboards.length;
    renderBillboardShowcase();
  };

  window.cmsGoBillboard = function (idx) {
    if (idx >= 0 && idx < billboards.length) {
      currentBillboardIndex = idx;
      renderBillboardShowcase();
    }
  };

  window.cmsPauseBillboard = function () {
    if (billboardTimer) clearInterval(billboardTimer);
  };

  window.cmsResumeBillboard = function () {
    startBillboardTimer();
  };

  // ---------------------------------------------------------
  // 4. MEDICAL VIDEOS PLAYER & PLAYLIST SYSTEM
  // ---------------------------------------------------------
  async function initMedicalVideos() {
    try {
      const res = await fetch(`/api/videos.php?_t=${Date.now()}`);
      const data = await res.json();
      if (data.success && data.data && data.data.length > 0) {
        videos = data.data;
        try { sessionStorage.setItem('njap_videos', JSON.stringify(videos)); } catch(e) {}
        if (!currentVideo) currentVideo = videos[0];
      }
    } catch (e) {}
  }

  function renderVideoPlayerAndList() {
    const playerBox = document.getElementById('medical-video-player-box');
    const infoBox = document.getElementById('medical-video-info-box');
    const playlistBox = document.getElementById('medical-videos-playlist');
    const paginationBox = document.getElementById('medical-videos-pagination');
    const countBadge = document.getElementById('medical-videos-count-badge');

    if (!playerBox || videos.length === 0) return;

    const filtered = activeVideoCategory === '전체' 
      ? videos 
      : videos.filter(v => v.category === activeVideoCategory);

    if (!filtered.some(v => v.id === (currentVideo ? currentVideo.id : null))) {
      currentVideo = filtered[0] || videos[0];
    }
    const cur = currentVideo || filtered[0];

    // Main Player
    if (cur) {
      let ytId = cur.youtubeId;
      if (!ytId && cur.youtubeUrl) {
        const m = cur.youtubeUrl.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=))([\w-]{11})/);
        if (m) ytId = m[1];
      }
      if (ytId) {
        playerBox.innerHTML = `
          <iframe class="w-full h-full border-0" 
            src="https://www.youtube.com/embed/${ytId}?autoplay=1&rel=0&modestbranding=1" 
            title="${escapeHtml(cur.title)}" 
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
            allowfullscreen>
          </iframe>
        `;
      } else if (cur.videoFile || cur.videoUrl) {
        playerBox.innerHTML = `<video class="w-full h-full object-cover bg-black" src="${cur.videoFile || cur.videoUrl}" controls autoplay playsinline></video>`;
      } else {
        playerBox.innerHTML = `
          <div class="relative w-full h-full bg-slate-900 group cursor-pointer" onclick="window.cmsSelectVideo('${cur.id}')">
            <img src="${cur.thumbnail || cur.thumbnailUrl || 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&q=80'}" 
              alt="${escapeHtml(cur.title)}" class="w-full h-full object-cover">
            <div class="absolute inset-0 bg-black/30 flex items-center justify-center">
              <div class="w-16 h-16 rounded-full bg-red-600 text-white flex items-center justify-center text-2xl shadow-2xl">▶</div>
            </div>
          </div>
        `;
      }

      if (infoBox) {
        infoBox.innerHTML = `
          <div class="flex items-center gap-3 text-xs text-slate-500 flex-wrap">
            <span class="font-bold text-red-600 bg-red-50 border border-red-100 px-2.5 py-0.5 rounded-full">${escapeHtml(cur.category || '의학뉴스')}</span>
            <span>·</span>
            <span class="font-semibold text-slate-800">${escapeHtml(cur.doctor || cur.speaker || '한인 전문의')}</span>
            <span>·</span>
            <span class="text-slate-600">⏱ ${escapeHtml(cur.duration || '10:00')}</span>
            <span>·</span>
            <span class="text-slate-600">👁️ ${escapeHtml(cur.views || '조회수')}</span>
          </div>
          <h3 class="font-extrabold text-xl sm:text-2xl text-slate-900 leading-snug tracking-tight">
            ${escapeHtml(cur.title)}
          </h3>
          <p class="text-xs sm:text-sm text-slate-600 leading-relaxed pt-1">
            ${escapeHtml(cur.summary || cur.description || '')}
          </p>
        `;
      }
    }

    // Playlist
    const totalPages = Math.ceil(filtered.length / VIDEOS_PER_PAGE) || 1;
    if (currentVideoPage > totalPages) currentVideoPage = totalPages;
    if (currentVideoPage < 1) currentVideoPage = 1;

    const startIdx = (currentVideoPage - 1) * VIDEOS_PER_PAGE;
    const pageVideos = filtered.slice(startIdx, startIdx + VIDEOS_PER_PAGE);

    if (countBadge) {
      countBadge.textContent = `${filtered.length}개 영상`;
    }

    if (playlistBox) {
      playlistBox.innerHTML = pageVideos.map(v => {
        const isPlaying = cur && cur.id === v.id;
        return `
          <div onclick="window.cmsSelectVideo('${v.id}')" 
            class="flex gap-3.5 p-3 rounded-2xl border transition-all duration-200 cursor-pointer ${
              isPlaying 
                ? 'bg-red-50/70 border-red-300 ring-2 ring-red-400 shadow-sm' 
                : 'bg-white border-slate-200/80 hover:bg-slate-50 hover:border-slate-300 shadow-xs'
            }">
            <div class="relative w-28 h-20 sm:w-32 sm:h-20 rounded-xl overflow-hidden shrink-0 bg-black">
              <img src="${v.thumbnail || v.thumbnailUrl || 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=400&q=80'}" 
                alt="${escapeHtml(v.title)}" class="w-full h-full object-cover">
              <div class="absolute bottom-1 right-1 bg-black/85 text-white font-mono font-bold text-[10px] px-1.5 py-0.5 rounded">
                ${escapeHtml(v.duration || '10:00')}
              </div>
            </div>
            <div class="flex-1 min-w-0 flex flex-col justify-between py-0.5">
              <div>
                <span class="text-[10px] font-bold text-red-600 uppercase tracking-wider block mb-0.5">
                  ${escapeHtml(v.category || '의학뉴스')}
                </span>
                <h4 class="font-bold text-xs sm:text-sm text-slate-900 leading-snug line-clamp-2 ${isPlaying ? 'text-red-700' : ''}">
                  ${escapeHtml(v.title)}
                </h4>
              </div>
              <div class="flex items-center gap-2 text-[11px] text-slate-500 mt-1.5">
                <span class="truncate">${escapeHtml(v.doctor || v.speaker || '의학 전문의')}</span>
                <span>·</span>
                <span class="text-slate-700 font-semibold">${escapeHtml(v.views || '조회수')}</span>
              </div>
            </div>
          </div>
        `;
      }).join('');
    }

    if (paginationBox) {
      paginationBox.innerHTML = `
        <button onclick="window.cmsPrevVideoPage()" ${currentVideoPage <= 1 ? 'disabled class="opacity-30 cursor-not-allowed"' : 'class="cursor-pointer font-bold text-slate-700 hover:text-red-600"'}>‹ 이전</button>
        <span class="text-xs font-mono font-bold">${currentVideoPage} / ${totalPages}</span>
        <button onclick="window.cmsNextVideoPage()" ${currentVideoPage >= totalPages ? 'disabled class="opacity-30 cursor-not-allowed"' : 'class="cursor-pointer font-bold text-slate-700 hover:text-red-600"'}>다음 ›</button>
      `;
    }
  }

  window.cmsSetVideoCat = function(c) {
    activeVideoCategory = c;
    currentVideoPage = 1;
    document.querySelectorAll('#medical-videos-categories button').forEach(btn => {
      if (btn.textContent.trim() === c) {
        btn.className = 'text-xs font-semibold px-4 py-2 rounded-full transition-all whitespace-nowrap bg-red-600 text-white shadow-sm cursor-pointer';
      } else {
        btn.className = 'text-xs font-medium px-4 py-2 rounded-full transition-all whitespace-nowrap bg-white border border-slate-200/80 text-slate-700 hover:bg-slate-100 hover:text-slate-900 cursor-pointer';
      }
    });
    renderVideoPlayerAndList();
  };
  window.cmsPrevVideoPage = function() { if (currentVideoPage > 1) { currentVideoPage--; renderVideoPlayerAndList(); } };
  window.cmsNextVideoPage = function() { currentVideoPage++; renderVideoPlayerAndList(); };
  window.cmsSelectVideo = function(id) { currentVideo = videos.find(v => v.id === id); renderVideoPlayerAndList(); };

  // ---------------------------------------------------------
  // 5. BLOG LIVE SEARCH & CATEGORY FILTER
  // ---------------------------------------------------------
  async function initBlogInteractivity() {
    const searchInput = document.getElementById('cms-blog-search-input');
    const catContainer = document.getElementById('cms-blog-categories');

    // Fetch fresh posts
    try {
      const res = await fetch(`/api/posts.php?_t=${Date.now()}`);
      const data = await res.json();
      if (data.success && data.data) {
        posts = data.data;
        try { sessionStorage.setItem('njap_posts', JSON.stringify(posts)); } catch(e) {}
      }
    } catch(e) {}

    if (catContainer && !catContainer.dataset.bound) {
      catContainer.dataset.bound = '1';
      catContainer.querySelectorAll('button').forEach(btn => {
        btn.addEventListener('click', function(e) {
          e.preventDefault();
          blogActiveCategory = this.textContent.trim();
          catContainer.querySelectorAll('button').forEach(b => {
            b.className = 'text-sm font-sans font-medium px-4 py-1.5 rounded-full border transition-all duration-200 border-brand-border text-brand-muted hover:border-brand-blue hover:text-brand-blue bg-white cursor-pointer';
          });
          this.className = 'text-sm font-sans font-medium px-4 py-1.5 rounded-full border transition-all duration-200 bg-brand-gradient text-white border-transparent shadow-sm cursor-pointer';
          filterBlogList();
        });
      });
    }

    if (searchInput && !searchInput.dataset.bound) {
      searchInput.dataset.bound = '1';
      searchInput.addEventListener('input', function() {
        blogSearchQuery = this.value.trim().toLowerCase();
        filterBlogList();
      });
    }
  }

  function filterBlogList() {
    const blogContainer = document.getElementById('cms-blog-posts-grid');
    if (!blogContainer || posts.length === 0) return;

    let filtered = posts;
    if (blogActiveCategory && blogActiveCategory !== '전체') {
      filtered = filtered.filter(p => (p.category || '').toLowerCase() === blogActiveCategory.toLowerCase());
    }
    if (blogSearchQuery) {
      filtered = filtered.filter(p => 
        (p.title && p.title.toLowerCase().includes(blogSearchQuery)) ||
        (p.excerpt && p.excerpt.toLowerCase().includes(blogSearchQuery)) ||
        (p.content && p.content.toLowerCase().includes(blogSearchQuery)) ||
        (p.author && p.author.toLowerCase().includes(blogSearchQuery))
      );
    }

    if (filtered.length === 0) {
      blogContainer.innerHTML = `
        <div class="col-span-full py-16 text-center text-slate-500">
          <p class="text-lg font-medium">검색 조건에 맞는 기사가 없습니다.</p>
          <p class="text-sm text-slate-400 mt-1">다른 검색어나 카테고리를 선택해보세요.</p>
        </div>
      `;
      return;
    }

    blogContainer.innerHTML = filtered.map(p => `
      <a class="group card-hover" href="/blog/${p.slug || p.id}">
        <article class="bg-white rounded-2xl overflow-hidden border border-brand-border h-full flex flex-col shadow-sm">
          <div class="relative h-52 overflow-hidden bg-gray-100">
            <img src="${p.coverImage || (p.images && p.images[0]) || 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=800&q=80'}" 
              alt="${escapeHtml(p.title)}" class="object-cover w-full h-full group-hover:scale-105 transition-transform duration-500">
            <div class="absolute top-3 left-3">
              <span class="tag-pill bg-brand-blue text-white font-bold text-xs px-3 py-1 rounded-full shadow">${escapeHtml(p.category || '건강 뉴스')}</span>
            </div>
          </div>
          <div class="p-6 flex flex-col flex-1">
            <div class="flex items-center gap-3 text-xs font-sans text-brand-muted mb-3">
              <span>${escapeHtml(p.date || '2026')}</span>
              <span>·</span>
              <span>⏱ ${escapeHtml(p.readTime || '3분')} 읽기</span>
              <span>·</span>
              <span>${escapeHtml(p.author || '편집부')}</span>
            </div>
            <h2 class="font-serif text-xl text-brand-dark leading-snug mb-3 line-clamp-2 group-hover:text-brand-blue transition-colors duration-200">${escapeHtml(p.title)}</h2>
            <p class="text-sm font-sans text-brand-muted leading-relaxed line-clamp-3 flex-1">${escapeHtml(p.excerpt || '')}</p>
            <div class="mt-5 flex items-center gap-1 text-sm font-sans font-medium text-brand-blue">
              기사 읽기 <span class="group-hover:translate-x-1 transition-transform inline-block">→</span>
            </div>
          </div>
        </article>
      </a>
    `).join('');
  }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  // ---------------------------------------------------------
  // 6. INITIALIZATION
  // ---------------------------------------------------------
  document.addEventListener('DOMContentLoaded', () => {
    initMobileMenu();
    initBillboards();
    initMedicalVideos();
    initBlogInteractivity();
  });

})();
