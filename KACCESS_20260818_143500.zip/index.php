<?php
/**
 * Healthcare Access Portal - Main Homepage (Instant Dynamic PHP Engine)
 * Renders the latest CMS Billboard, Top Story, Real-time News, Policy Reports, and Video News directly on the server.
 */
require_once __DIR__ . '/api/db.php';

$db = get_db_data();
$billboards = $db['billboards'] ?? [];
$videos = $db['videos'] ?? [];
$posts = $db['posts'] ?? [];

// Filter active billboards
$activeBillboards = array_values(array_filter($billboards, function($b) {
    return !isset($b['active']) || $b['active'] !== false;
}));
if (empty($activeBillboards) && !empty($billboards)) {
    $activeBillboards = $billboards;
}

// Find Top Story and other posts
$topStory = null;
foreach ($posts as $p) {
    if (!empty($p['isTopStory'])) {
        $topStory = $p;
        break;
    }
}
if (!$topStory && !empty($posts)) {
    $topStory = $posts[0];
}

$otherPosts = array_values(array_filter($posts, function($p) use ($topStory) {
    return !$topStory || $p['id'] !== $topStory['id'];
}));

$latestNews = array_slice($otherPosts, 0, 4);
$reportNews = array_slice($otherPosts, 4, 4);
if (empty($reportNews) && count($otherPosts) > 0) {
    $reportNews = array_slice($otherPosts, 0, 4);
}

// Live update headline
$liveHeadline = !empty($posts[0]['title']) ? $posts[0]['title'] : '뉴저지 한인 의료 접근 포털 — 2026 메디케어 및 ACA 오바마케어 수혜 자격 종합 안내 개시';

// Medical videos
$activeVideos = array_values(array_filter($videos, function($v) {
    return !isset($v['active']) || $v['active'] !== false;
}));
if (empty($activeVideos) && !empty($videos)) {
    $activeVideos = $videos;
}
$mainVideo = $activeVideos[0] ?? null;
$playlistVideos = array_slice($activeVideos, 0, 4);
?>
<!DOCTYPE html>
<html lang="ko" class="h-full antialiased">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Healthcare Access Portal | 뉴저지 한인 의료 정보 포털</title>
  <meta name="description" content="뉴저지 한인 커뮤니티를 위한 의료 접근 및 건강 정보 포털. 메디케어, ACA, 의료 상담을 한국어로 제공합니다." />
  <meta property="og:title" content="Healthcare Access Portal | 뉴저지 한인 의료 정보 포털" />
  <meta property="og:description" content="뉴저지 한인 커뮤니티를 위한 의료 접근 및 건강 정보 포털. 메디케어, ACA, 의료 상담을 한국어로 제공합니다." />
  <meta property="og:image" content="<?= htmlspecialchars($topStory['coverImage'] ?? '/logo-icon.svg') ?>" />
  <link rel="icon" href="/favicon.ico" sizes="256x256" type="image/x-icon" />

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/static/pretendard.min.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="/_next/static/chunks/1fosv8xgmgdeu.css" />

  <style>
    :root, html, body {
      font-family: "Pretendard Variable", Pretendard, "Noto Sans KR", -apple-system, BlinkMacSystemFont, system-ui, Roboto, sans-serif !important;
    }
    html, body {
      overflow-x: hidden !important;
      max-width: 100% !important;
    }
    @keyframes marqueeScroll {
      0% { transform: translateX(0); }
      100% { transform: translateX(-50%); }
    }
    .marquee-track {
      display: inline-flex !important;
      white-space: nowrap !important;
      will-change: transform;
      animation: marqueeScroll 25s linear infinite !important;
    }
    .marquee-track:hover {
      animation-play-state: paused;
    }
    #gallery-billboard-section {
      width: 100vw !important;
      max-width: 100vw !important;
      position: relative !important;
      left: 50% !important;
      right: 50% !important;
      margin-left: -50vw !important;
      margin-right: -50vw !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
    }
  </style>
</head>
<body class="min-h-full flex flex-col bg-brand-light">

  <!-- Top Marquee Banner -->
  <div class="fixed top-0 left-0 right-0 z-50 h-[45px] overflow-hidden flex items-center" style="background:linear-gradient(135deg, #0f3a9e 0%, #5e0f73 100%)">
    <div class="marquee-track whitespace-nowrap">
      <?php for ($i = 0; $i < 6; $i++): ?>
        <span class="inline-block font-sans text-xs text-white/90 tracking-wide px-12">
          <span class="opacity-60 mr-3">✦</span>New Jersey's Leading Korean Healthcare Access &amp; Navigation Portal — 뉴저지 한인 의료 정보 포털<span class="opacity-60 ml-3">✦</span>
        </span>
      <?php endfor; ?>
    </div>
  </div>

  <!-- Main Navigation Bar -->
  <nav class="fixed top-0 left-0 right-0 z-50 transition-all duration-300 bg-white/80 backdrop-blur-sm" style="top:45px">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="flex items-center justify-between h-16">
        <a class="flex-shrink-0 group flex items-center gap-2.5" href="/">
          <div class="w-8 h-8 flex items-center justify-center flex-shrink-0">
            <img src="/logo-icon.svg" alt="NJAP Logo" class="w-full h-full object-contain transition-transform group-hover:scale-105" />
          </div>
          <div>
            <span class="font-serif text-xl text-brand-dark group-hover:text-brand-blue transition-colors duration-200 block">Healthcare Access Portal</span>
            <span class="block text-[10px] font-sans text-brand-muted leading-tight -mt-0.5">뉴저지 한인 의료 접근 포털</span>
          </div>
        </a>
        <div class="hidden md:flex items-center gap-8">
          <a class="nav-link pb-0.5 font-bold text-brand-blue" href="/">홈</a>
          <a class="nav-link pb-0.5 font-medium text-slate-700 hover:text-brand-blue" href="/blog">뉴스</a>
          <a class="nav-link pb-0.5 font-medium text-slate-700 hover:text-brand-blue" href="/medicare">메디케어 &amp; ACA</a>
          <a class="nav-link pb-0.5 font-medium text-slate-700 hover:text-brand-blue" href="/tool">환자도우미</a>
          <a class="nav-link pb-0.5 font-medium text-slate-700 hover:text-brand-blue" href="/about">소개</a>
        </div>
        <div class="flex items-center gap-4">
          <button id="mobile-menu-btn" class="md:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors" aria-label="Menu">
            <div class="w-5 h-4 flex flex-col justify-between">
              <span class="block h-0.5 bg-brand-dark rounded-full"></span>
              <span class="block h-0.5 bg-brand-dark rounded-full"></span>
              <span class="block h-0.5 bg-brand-dark rounded-full"></span>
            </div>
          </button>
        </div>
      </div>
    </div>
    <div id="mobile-menu-dropdown" class="md:hidden overflow-hidden transition-all duration-300 max-h-0 opacity-0 bg-white/95 backdrop-blur-md border-t border-brand-border px-4 py-4 flex flex-col gap-3">
      <a class="font-sans text-sm font-bold text-brand-blue py-2 border-b border-brand-border/50" href="/">홈</a>
      <a class="font-sans text-sm font-medium text-brand-dark hover:text-brand-blue py-2 border-b border-brand-border/50" href="/blog">뉴스</a>
      <a class="font-sans text-sm font-medium text-brand-dark hover:text-brand-blue py-2 border-b border-brand-border/50" href="/medicare">메디케어 &amp; ACA</a>
      <a class="font-sans text-sm font-medium text-brand-dark hover:text-brand-blue py-2 border-b border-brand-border/50" href="/tool">환자도우미</a>
      <a class="font-sans text-sm font-medium text-brand-dark hover:text-brand-blue py-2 border-b border-brand-border/50" href="/about">소개</a>
    </div>
  </nav>

  <div class="h-[109px]"></div>

  <main class="flex-1">
    <div class="flex flex-col bg-[#F3F3F5] min-h-screen text-[#111111] font-sans">
      
      <!-- 1. 100vw Panoramic Billboard Section -->
      <section id="gallery-billboard-section" class="w-full font-sans bg-slate-950 my-4" style="width:100vw; max-width:100vw; position:relative; left:50%; right:50%; margin-left:-50vw; margin-right:-50vw;">
        <div id="gallery-billboard-container" class="w-full relative group">
          <?php if (!empty($activeBillboards)): 
            $b = $activeBillboards[0];
            $isVideo = ($b['mediaType'] ?? '') === 'video' || (isset($b['mediaUrl']) && (str_ends_with($b['mediaUrl'], '.mp4') || str_ends_with($b['mediaUrl'], '.webm')));
          ?>
          <div class="relative w-full overflow-hidden bg-slate-950 select-none group" style="aspect-ratio: 1920 / 566; width: 100%; max-height: 480px;">
            <a href="<?= htmlspecialchars($b['linkUrl'] ?? '/about#contact') ?>" class="block relative w-full h-full cursor-pointer" title="<?= htmlspecialchars($b['title'] ?? '') ?>">
              <div class="w-full h-full relative overflow-hidden">
                <?php if ($isVideo): ?>
                  <video src="<?= htmlspecialchars($b['mediaUrl']) ?>" class="w-full h-full object-cover" autoplay muted loop playsinline></video>
                <?php else: ?>
                  <img id="billboard-active-img" 
                    src="<?= htmlspecialchars($b['mediaUrl'] ?: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=2000&q=85&auto=format') ?>" 
                    alt="<?= htmlspecialchars($b['title'] ?? '') ?>" 
                    class="w-full h-full object-cover transform scale-100 group-hover:scale-103 transition-transform duration-1000 ease-out">
                <?php endif; ?>
                <div class="absolute inset-0 bg-gradient-to-t from-black/95 via-black/40 to-black/15 pointer-events-none"></div>
                <div class="absolute inset-0 bg-gradient-to-r from-black/75 via-transparent to-black/25 pointer-events-none"></div>
              </div>

              <div class="absolute inset-0 flex items-end">
                <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full pb-4 sm:pb-6 flex items-end justify-between gap-4">
                  <div class="max-w-3xl space-y-1 sm:space-y-2">
                    <div class="flex items-center gap-2">
                      <span class="bg-red-600 text-white text-[10px] sm:text-xs font-extrabold px-3 py-0.5 sm:py-1 rounded-full uppercase tracking-wider shadow">
                        <?= htmlspecialchars($b['category'] ?? 'SPECIAL CAMPAIGN') ?>
                      </span>
                      <span class="text-xs font-mono text-white/80 bg-black/60 px-2.5 py-0.5 rounded-full border border-white/15">
                        1 / <?= count($activeBillboards) ?>
                      </span>
                    </div>
                    <h3 class="font-extrabold text-base sm:text-2xl md:text-3xl text-white tracking-tight leading-snug drop-shadow-md group-hover:text-blue-300 transition-colors line-clamp-1">
                      <?= htmlspecialchars($b['title'] ?? '') ?>
                    </h3>
                    <p class="text-white/85 text-xs sm:text-sm line-clamp-1 max-w-2xl font-normal drop-shadow hidden sm:block">
                      <?= htmlspecialchars($b['subtitle'] ?? '') ?>
                    </p>
                  </div>

                  <div class="flex items-center gap-2 shrink-0">
                    <span class="inline-flex items-center gap-1.5 bg-gradient-to-r from-red-600 to-brand-blue text-white font-extrabold text-xs sm:text-sm px-4 py-2 sm:px-5 sm:py-2.5 rounded-xl shadow-xl">
                      <span><?= htmlspecialchars($b['linkText'] ?? '자세히 보기') ?></span>
                      <span>→</span>
                    </span>
                  </div>
                </div>
              </div>
            </a>

            <button onclick="event.stopPropagation(); event.preventDefault(); window.cmsPrevBillboard();" 
              class="absolute left-4 sm:left-8 top-1/2 -translate-y-1/2 w-9 h-9 sm:w-12 sm:h-12 rounded-full bg-black/50 hover:bg-red-600 text-white backdrop-blur-md border border-white/20 flex items-center justify-center text-xl sm:text-3xl transition-all duration-200 z-20 hover:scale-110 shadow-2xl cursor-pointer"
              aria-label="Previous Slide">
              ‹
            </button>

            <button onclick="event.stopPropagation(); event.preventDefault(); window.cmsNextBillboard();" 
              class="absolute right-4 sm:right-8 top-1/2 -translate-y-1/2 w-9 h-9 sm:w-12 sm:h-12 rounded-full bg-black/50 hover:bg-red-600 text-white backdrop-blur-md border border-white/20 flex items-center justify-center text-xl sm:text-3xl transition-all duration-200 z-20 hover:scale-110 shadow-2xl cursor-pointer"
              aria-label="Next Slide">
              ›
            </button>

            <div class="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-2 z-20">
              <?php foreach ($activeBillboards as $idx => $dummy): ?>
                <button onclick="event.stopPropagation(); event.preventDefault(); window.cmsGoBillboard(<?= $idx ?>);" 
                  class="transition-all duration-300 <?= $idx === 0 ? 'w-6 h-1.5 sm:w-8 sm:h-2 bg-white rounded-full shadow-lg ring-1 ring-white/50' : 'w-2 h-1.5 sm:w-2.5 sm:h-2 bg-white/40 hover:bg-white/80 rounded-full' ?>">
                </button>
              <?php endforeach; ?>
            </div>
          </div>
          <?php endif; ?>
        </div>
      </section>

      <!-- 2. Live Updates Bar -->
      <div class="bg-[#0C0C0E] text-white border-b border-white/10 py-2.5 px-4 sm:px-6 lg:px-8">
        <div class="max-w-7xl mx-auto flex items-center justify-between gap-4 text-xs font-sans">
          <div class="flex items-center gap-3 overflow-hidden">
            <span class="bg-red-600 text-white font-extrabold px-2.5 py-0.5 rounded text-[11px] tracking-wider uppercase shrink-0 animate-pulse">LIVE UPDATES</span>
            <p class="truncate text-white/90 font-medium"><?= htmlspecialchars($liveHeadline) ?></p>
          </div>
          <a class="shrink-0 text-white/70 hover:text-white transition-colors underline font-medium" href="/blog">전체 뉴스 →</a>
        </div>
      </div>

      <!-- 3. Top Story & Real-time Latest News Grid -->
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 w-full space-y-10">
        <section class="bg-white rounded-2xl p-5 sm:p-7 border border-gray-200/90 shadow-sm">
          <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            <!-- Left: Top Story -->
            <?php if ($topStory): 
              $summaryPoints = $topStory['summaryPoints'] ?? [];
              if (is_string($summaryPoints)) $summaryPoints = explode("\n", $summaryPoints);
              if (empty($summaryPoints)) {
                  $summaryPoints = ['공식 당국 승인 안전 가이드라인 적용 및 신속 지원', '뉴저지 거주 한인 대상 한국어 무료 상담 창구 운영', '의료 혜택 및 처방약 복용 시 주의 사항 안내'];
              }
              $topCover = $topStory['coverImage'] ?: (!empty($topStory['images'][0]) ? $topStory['images'][0] : 'https://images.unsplash.com/photo-1628771065117-74ccb5690668?w=1200&q=80&auto=format');
            ?>
            <div id="homepage-top-story-box" class="lg:col-span-7 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-gray-200 pb-8 lg:pb-0 lg:pr-8">
              <a class="group block" href="/blog/<?= htmlspecialchars($topStory['slug'] ?: $topStory['id']) ?>">
                <div class="flex items-center gap-2 mb-3">
                  <span class="w-2.5 h-2.5 rounded-full bg-red-600"></span>
                  <span class="text-xs font-bold text-red-600 uppercase tracking-widest"><?= htmlspecialchars($topStory['category'] ?: '주요 뉴스') ?></span>
                  <span class="text-xs text-gray-400">·</span>
                  <span class="text-xs text-gray-500"><?= htmlspecialchars($topStory['date'] ?: date('Y-m-d')) ?></span>
                </div>
                <h1 class="font-sans font-extrabold text-2xl sm:text-4xl text-gray-950 leading-tight mb-4 tracking-tight group-hover:text-brand-blue transition-colors">
                  <?= htmlspecialchars($topStory['title'] ?? '') ?>
                </h1>
                <div class="relative h-64 sm:h-96 w-full rounded-xl overflow-hidden mb-5 bg-gray-100 shadow-sm">
                  <img src="<?= htmlspecialchars($topCover) ?>" 
                    alt="<?= htmlspecialchars($topStory['title'] ?? '') ?>" 
                    class="object-cover group-hover:scale-102 transition-transform duration-500 w-full h-full">
                </div>
                <p class="text-gray-700 text-sm sm:text-base leading-relaxed mb-5">
                  <?= htmlspecialchars($topStory['excerpt'] ?? '') ?>
                </p>
              </a>
              <div class="bg-gray-50 rounded-xl p-4 border border-gray-200/80 mb-5">
                <p class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">핵심 요약</p>
                <ul class="space-y-1.5 text-xs sm:text-sm text-gray-800 font-medium">
                  <?php foreach (array_slice($summaryPoints, 0, 3) as $pt): ?>
                    <li class="flex items-start gap-2">
                      <span class="text-red-600 font-bold">•</span>
                      <span><?= htmlspecialchars($pt) ?></span>
                    </li>
                  <?php endforeach; ?>
                </ul>
              </div>
              <div class="flex items-center justify-between text-xs text-gray-500 pt-3 border-t border-gray-100">
                <div class="flex items-center gap-2">
                  <span class="font-bold text-gray-900"><?= htmlspecialchars($topStory['author'] ?? '편집부') ?></span>
                  <span>·</span>
                  <span>⏱ <?= htmlspecialchars($topStory['readTime'] ?? '3분') ?></span>
                </div>
                <span class="text-red-600 font-semibold text-[11px] uppercase tracking-wider">TOP STORY</span>
              </div>
            </div>
            <?php endif; ?>

            <!-- Right: Real-time Latest News -->
            <div class="lg:col-span-5 flex flex-col justify-between">
              <div>
                <div class="flex items-center justify-between mb-4 pb-2 border-b border-gray-900">
                  <h2 class="font-extrabold text-lg text-gray-950 uppercase tracking-wider flex items-center gap-2">
                    <span class="w-3 h-3 bg-red-600 inline-block"></span>실시간 주요 뉴스
                  </h2>
                  <span class="text-xs text-gray-400">LATEST</span>
                </div>
                <div id="homepage-latest-news-box" class="divide-y divide-gray-200">
                  <?php foreach ($latestNews as $item): 
                    $itemCover = $item['coverImage'] ?: (!empty($item['images'][0]) ? $item['images'][0] : 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=400&q=80');
                  ?>
                    <a class="group py-3.5 first:pt-0 last:pb-0 flex gap-4 items-start" href="/blog/<?= htmlspecialchars($item['slug'] ?: $item['id']) ?>">
                      <div class="flex-1 min-w-0">
                        <span class="text-[11px] font-bold text-brand-blue uppercase tracking-wide block mb-1">
                          <?= htmlspecialchars($item['category'] ?: '뉴스') ?>
                        </span>
                        <h3 class="font-bold text-sm sm:text-base text-gray-900 leading-snug line-clamp-2 group-hover:text-brand-blue transition-colors">
                          <?= htmlspecialchars($item['title'] ?? '') ?>
                        </h3>
                        <div class="flex items-center gap-2 text-[11px] text-gray-400 mt-2">
                          <span><?= htmlspecialchars($item['date'] ?? '') ?></span>
                          <span>·</span>
                          <span><?= htmlspecialchars($item['readTime'] ?? '3분') ?></span>
                        </div>
                      </div>
                      <div class="relative w-20 h-20 sm:w-24 sm:h-24 rounded-lg overflow-hidden shrink-0 bg-gray-100 border border-gray-200">
                        <img src="<?= htmlspecialchars($itemCover) ?>" alt="<?= htmlspecialchars($item['title'] ?? '') ?>" class="object-cover group-hover:scale-105 transition-transform w-full h-full">
                      </div>
                    </a>
                  <?php endforeach; ?>
                </div>
              </div>
              <div class="mt-6 pt-4 border-t border-gray-100">
                <a class="w-full text-center block py-2.5 bg-gray-900 hover:bg-black text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-colors" href="/blog">
                  모든 건강 뉴스 아카이브 탐색 →
                </a>
              </div>
            </div>

          </div>
        </section>

        <!-- 4. Health Policy & Medicare Reports -->
        <section>
          <div class="flex items-center justify-between mb-4 pb-2 border-b-2 border-gray-900">
            <h2 class="font-extrabold text-xl text-gray-950 uppercase tracking-wider">보건 정책 &amp; 메디케어 리포트</h2>
            <a class="text-xs font-bold text-brand-blue hover:underline" href="/blog">전체보기 →</a>
          </div>
          <div id="homepage-reports-grid" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            <?php foreach ($reportNews as $p): 
              $pCover = $p['coverImage'] ?: (!empty($p['images'][0]) ? $p['images'][0] : 'https://images.unsplash.com/photo-1541781774459-bb2af2f05b55?w=800&q=80');
            ?>
              <a class="group card-hover" href="/blog/<?= htmlspecialchars($p['slug'] ?: $p['id']) ?>">
                <article class="bg-white rounded-2xl p-4 border border-gray-200/90 h-full flex flex-col justify-between shadow-sm">
                  <div>
                    <div class="relative h-40 w-full rounded-xl overflow-hidden mb-3 bg-gray-100">
                      <img src="<?= htmlspecialchars($pCover) ?>" alt="<?= htmlspecialchars($p['title'] ?? '') ?>" class="object-cover group-hover:scale-105 transition-transform duration-500 w-full h-full">
                    </div>
                    <span class="text-[11px] font-bold text-red-600 uppercase tracking-wider block mb-1"><?= htmlspecialchars($p['category'] ?: '리포트') ?></span>
                    <h3 class="font-bold text-base text-gray-900 leading-snug line-clamp-2 mb-2 group-hover:text-brand-blue transition-colors">
                      <?= htmlspecialchars($p['title'] ?? '') ?>
                    </h3>
                    <p class="text-xs text-gray-600 line-clamp-2 leading-relaxed mb-4">
                      <?= htmlspecialchars($p['excerpt'] ?? '') ?>
                    </p>
                  </div>
                  <div class="flex items-center justify-between text-[11px] text-gray-400 pt-3 border-t border-gray-100">
                    <span><?= htmlspecialchars($p['date'] ?? '') ?></span>
                    <span>⏱ <?= htmlspecialchars($p['readTime'] ?? '3분') ?></span>
                  </div>
                </article>
              </a>
            <?php endforeach; ?>
          </div>
        </section>

        <!-- 5. One-stop Coverage & Patient Services -->
        <section class="bg-brand-darker text-white rounded-3xl p-6 sm:p-10 border border-white/10 shadow-xl">
          <div class="max-w-3xl mb-8">
            <span class="bg-blue-500/20 text-blue-300 border border-blue-400/30 text-xs font-extrabold uppercase tracking-widest px-3 py-1 rounded-full inline-block mb-3">SPECIAL COVERAGE &amp; PATIENT SERVICES</span>
            <h2 class="font-extrabold text-3xl sm:text-4xl text-white mb-3">원스톱 의료 접근 &amp; 환자 종합 센터</h2>
            <p class="text-white/70 text-sm sm:text-base leading-relaxed">보험 자격 진단부터 병원 사전접수, 의학 용어 사전 및 의료비 지원 신청까지 한곳에서 이용하실 수 있습니다.</p>
          </div>
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            <a class="group" href="/tool">
              <div class="bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl p-5 h-full flex flex-col justify-between transition-all duration-300 group-hover:border-blue-400/50">
                <div>
                  <div class="flex items-center justify-between mb-4"><span class="text-2xl">🏥</span><span class="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-white/10 text-white/80">INSURANCE MATCHER</span></div>
                  <h3 class="font-bold text-lg text-white mb-2 group-hover:text-blue-300 transition-colors">메디케어 &amp; ACA 자격 진단</h3>
                  <p class="text-xs text-white/60 leading-relaxed mb-4">나이, 소득, 신분 상태에 따른 맞춤형 건강보험 혜택 및 보조금을 즉시 진단하세요.</p>
                </div>
                <div class="text-xs font-bold text-blue-400 group-hover:translate-x-1 transition-transform flex items-center gap-1">서비스 바로가기 →</div>
              </div>
            </a>
            <a class="group" href="/tool">
              <div class="bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl p-5 h-full flex flex-col justify-between transition-all duration-300 group-hover:border-blue-400/50">
                <div>
                  <div class="flex items-center justify-between mb-4"><span class="text-2xl">🧮</span><span class="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-white/10 text-white/80">CALCULATOR</span></div>
                  <h3 class="font-bold text-lg text-white mb-2 group-hover:text-blue-300 transition-colors">ACA 보험료 보조금 계산기</h3>
                  <p class="text-xs text-white/60 leading-relaxed mb-4">가족 수와 연 소득을 기반으로 지원받을 수 있는 세액 공제 보조금액을 산출합니다.</p>
                </div>
                <div class="text-xs font-bold text-blue-400 group-hover:translate-x-1 transition-transform flex items-center gap-1">서비스 바로가기 →</div>
              </div>
            </a>
            <a class="group" href="/tool">
              <div class="bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl p-5 h-full flex flex-col justify-between transition-all duration-300 group-hover:border-blue-400/50">
                <div>
                  <div class="flex items-center justify-between mb-4"><span class="text-2xl">📖</span><span class="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-white/10 text-white/80">DICTIONARY</span></div>
                  <h3 class="font-bold text-lg text-white mb-2 group-hover:text-blue-300 transition-colors">영-한 의학 용어 사전</h3>
                  <p class="text-xs text-white/60 leading-relaxed mb-4">미국 병원 진료실에서 자주 쓰는 필수 영문 의학 표현과 한국어 해설 모음.</p>
                </div>
                <div class="text-xs font-bold text-blue-400 group-hover:translate-x-1 transition-transform flex items-center gap-1">서비스 바로가기 →</div>
              </div>
            </a>
            <a class="group" href="/tool">
              <div class="bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl p-5 h-full flex flex-col justify-between transition-all duration-300 group-hover:border-blue-400/50">
                <div>
                  <div class="flex items-center justify-between mb-4"><span class="text-2xl">📋</span><span class="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-white/10 text-white/80">PATIENT PORTAL</span></div>
                  <h3 class="font-bold text-lg text-white mb-2 group-hover:text-blue-300 transition-colors">스마트 환자 서비스 &amp; 사전접수</h3>
                  <p class="text-xs text-white/60 leading-relaxed mb-4">병원 사전접수 차트 작성, 피검사 입력 및 의료비 탕감 지원 신청을 한곳에서 제공합니다.</p>
                </div>
                <div class="text-xs font-bold text-blue-400 group-hover:translate-x-1 transition-transform flex items-center gap-1">서비스 바로가기 →</div>
              </div>
            </a>
          </div>
        </section>

        <!-- 6. Medical Video News Section (의학비디오뉴스) -->
        <section id="medical-videos-section" class="bg-gradient-to-b from-slate-50/60 via-white to-slate-50/60 py-16 border-t border-b border-slate-200/60 font-sans">
          <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4 border-b border-slate-200/80 pb-5">
              <div>
                <div class="flex items-center gap-2 mb-1.5">
                  <span class="p-1.5 bg-red-50 text-red-600 rounded-lg text-lg border border-red-100 shadow-xs">🎬</span>
                  <span class="text-[10px] font-bold text-red-600 uppercase tracking-widest block">MEDICAL VIDEO NEWS</span>
                </div>
                <h2 class="font-extrabold text-2xl sm:text-3xl lg:text-4xl text-slate-900 tracking-tight">의학비디오뉴스</h2>
                <p class="text-xs sm:text-sm text-slate-600 mt-1.5 font-normal">한인 전문의와 병원이 직접 전하는 검증된 최신 의학 정보 및 건강 가이드</p>
              </div>
              <div id="medical-videos-categories" class="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
                <button onclick="window.cmsSetVideoCat('전체')" class="text-xs font-semibold px-4 py-2 rounded-full transition-all whitespace-nowrap bg-red-600 text-white shadow-sm cursor-pointer">전체</button>
                <button onclick="window.cmsSetVideoCat('심장 & 혈관')" class="text-xs font-medium px-4 py-2 rounded-full transition-all whitespace-nowrap bg-white border border-slate-200/80 text-slate-700 hover:bg-slate-100 hover:text-slate-900 cursor-pointer">심장 &amp; 혈관</button>
                <button onclick="window.cmsSetVideoCat('뇌신경 질환')" class="text-xs font-medium px-4 py-2 rounded-full transition-all whitespace-nowrap bg-white border border-slate-200/80 text-slate-700 hover:bg-slate-100 hover:text-slate-900 cursor-pointer">뇌신경 질환</button>
                <button onclick="window.cmsSetVideoCat('암 예방 & 검진')" class="text-xs font-medium px-4 py-2 rounded-full transition-all whitespace-nowrap bg-white border border-slate-200/80 text-slate-700 hover:bg-slate-100 hover:text-slate-900 cursor-pointer">암 예방 &amp; 검진</button>
                <button onclick="window.cmsSetVideoCat('관절 & 정형외과')" class="text-xs font-medium px-4 py-2 rounded-full transition-all whitespace-nowrap bg-white border border-slate-200/80 text-slate-700 hover:bg-slate-100 hover:text-slate-900 cursor-pointer">관절 &amp; 정형외과</button>
                <button onclick="window.cmsSetVideoCat('만성질환 관리')" class="text-xs font-medium px-4 py-2 rounded-full transition-all whitespace-nowrap bg-white border border-slate-200/80 text-slate-700 hover:bg-slate-100 hover:text-slate-900 cursor-pointer">만성질환 관리</button>
              </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              
              <!-- Main Video Player -->
              <div class="lg:col-span-7 xl:col-span-8 space-y-4">
                <div id="medical-video-player-box" class="relative aspect-video w-full rounded-2xl overflow-hidden bg-black border border-slate-200/80 shadow-md">
                  <?php if ($mainVideo): 
                    $ytId = $mainVideo['youtubeId'] ?? '';
                    if (!$ytId && !empty($mainVideo['youtubeUrl']) && preg_match('~(?:youtu\.be/|youtube\.com/(?:embed/|v/|watch\?v=))([\w-]{11})~', $mainVideo['youtubeUrl'], $m)) {
                        $ytId = $m[1];
                    }
                  ?>
                    <?php if ($ytId): ?>
                      <iframe class="w-full h-full border-0" 
                        src="https://www.youtube.com/embed/<?= $ytId ?>?autoplay=1&rel=0&modestbranding=1" 
                        title="<?= htmlspecialchars($mainVideo['title'] ?? '') ?>" 
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                        allowfullscreen>
                      </iframe>
                    <?php else: ?>
                      <div class="relative w-full h-full group cursor-pointer" onclick="window.cmsSelectVideo('<?= $mainVideo['id'] ?>')">
                        <img src="<?= htmlspecialchars($mainVideo['thumbnailUrl'] ?: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&q=80') ?>" alt="<?= htmlspecialchars($mainVideo['title'] ?? '') ?>" class="w-full h-full object-cover">
                        <div class="absolute inset-0 bg-black/40 flex items-center justify-center">
                          <div class="w-16 h-16 rounded-full bg-red-600 text-white flex items-center justify-center text-2xl shadow-2xl">▶</div>
                        </div>
                      </div>
                    <?php endif; ?>
                  <?php endif; ?>
                </div>

                <div id="medical-video-info-box" class="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-sm space-y-2.5">
                  <?php if ($mainVideo): ?>
                    <div class="flex items-center gap-3 text-xs text-slate-500 flex-wrap">
                      <span class="font-bold text-red-600 bg-red-50 border border-red-100 px-2.5 py-0.5 rounded-full"><?= htmlspecialchars($mainVideo['category'] ?: '의학뉴스') ?></span>
                      <span>·</span>
                      <span class="font-semibold text-slate-800"><?= htmlspecialchars($mainVideo['speaker'] ?: ($mainVideo['doctor'] ?: '한인 전문의')) ?></span>
                      <span>·</span>
                      <span class="text-slate-600">⏱ <?= htmlspecialchars($mainVideo['duration'] ?: '10:00') ?></span>
                      <span>·</span>
                      <span class="text-slate-600">👁️ <?= htmlspecialchars($mainVideo['views'] ?: '조회수') ?></span>
                    </div>
                    <h3 class="font-extrabold text-xl sm:text-2xl text-slate-900 leading-snug tracking-tight">
                      <?= htmlspecialchars($mainVideo['title'] ?? '') ?>
                    </h3>
                    <p class="text-xs sm:text-sm text-slate-600 leading-relaxed pt-1">
                      <?= htmlspecialchars($mainVideo['description'] ?: ($mainVideo['summary'] ?? '')) ?>
                    </p>
                  <?php endif; ?>
                </div>
              </div>

              <!-- Recommended Playlist -->
              <div class="lg:col-span-5 xl:col-span-4 space-y-4">
                <div class="flex items-center justify-between pb-2.5 border-b border-slate-200/80">
                  <h3 class="font-extrabold text-sm text-slate-900 uppercase tracking-wider flex items-center gap-2">
                    <span class="w-2.5 h-2.5 rounded-full bg-red-600 animate-pulse"></span>추천 의학 영상 플레이리스트
                  </h3>
                  <span id="medical-videos-count-badge" class="text-xs font-semibold text-slate-500"><?= count($activeVideos) ?>개 영상</span>
                </div>
                
                <div id="medical-videos-playlist" class="space-y-3">
                  <?php foreach ($playlistVideos as $v): 
                    $isPlaying = $mainVideo && $mainVideo['id'] === $v['id'];
                  ?>
                    <div onclick="window.cmsSelectVideo('<?= $v['id'] ?>')" 
                      class="flex gap-3.5 p-3 rounded-2xl border transition-all duration-200 cursor-pointer <?= $isPlaying ? 'bg-red-50/70 border-red-300 ring-2 ring-red-400 shadow-sm' : 'bg-white border-slate-200/80 hover:bg-slate-50 hover:border-slate-300 shadow-xs' ?>">
                      <div class="relative w-28 h-20 sm:w-32 sm:h-20 rounded-xl overflow-hidden shrink-0 bg-black">
                        <img src="<?= htmlspecialchars($v['thumbnailUrl'] ?: ($v['thumbnail'] ?: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=400&q=80')) ?>" alt="<?= htmlspecialchars($v['title'] ?? '') ?>" class="w-full h-full object-cover">
                        <div class="absolute bottom-1 right-1 bg-black/85 text-white font-mono font-bold text-[10px] px-1.5 py-0.5 rounded">
                          <?= htmlspecialchars($v['duration'] ?: '10:00') ?>
                        </div>
                      </div>
                      <div class="flex-1 min-w-0 flex flex-col justify-between py-0.5">
                        <div>
                          <span class="text-[10px] font-bold text-red-600 uppercase tracking-wider block mb-0.5">
                            <?= htmlspecialchars($v['category'] ?: '의학뉴스') ?>
                          </span>
                          <h4 class="font-bold text-xs sm:text-sm text-slate-900 leading-snug line-clamp-2 <?= $isPlaying ? 'text-red-700' : '' ?>">
                            <?= htmlspecialchars($v['title'] ?? '') ?>
                          </h4>
                        </div>
                        <div class="flex items-center gap-2 text-[11px] text-slate-500 mt-1.5">
                          <span class="truncate"><?= htmlspecialchars($v['speaker'] ?: ($v['doctor'] ?: '전문의')) ?></span>
                          <span>·</span>
                          <span class="text-slate-700 font-semibold"><?= htmlspecialchars($v['views'] ?: '조회수') ?></span>
                        </div>
                      </div>
                    </div>
                  <?php endforeach; ?>
                </div>

                <div id="medical-videos-pagination" class="flex items-center justify-between pt-3 border-t border-slate-200/80">
                  <button onclick="window.cmsPrevVideoPage()" class="cursor-pointer font-bold text-slate-700 hover:text-red-600">‹ 이전</button>
                  <span class="text-xs font-mono font-bold">1 / <?= max(1, ceil(count($activeVideos) / 4)) ?></span>
                  <button onclick="window.cmsNextVideoPage()" class="cursor-pointer font-bold text-slate-700 hover:text-red-600">다음 ›</button>
                </div>
              </div>

            </div>
          </div>
        </section>

      </div>
    </div>
  </main>

  <!-- Footer -->
  <footer class="bg-brand-darker text-white">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-10">
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
        <div class="lg:col-span-2">
          <a class="inline-flex items-center gap-3 mb-4 group" href="/">
            <img src="/logo-icon.svg" alt="NJAP Logo" style="width: 36px; height: 36px; object-fit: contain; filter: invert(1) brightness(2); flex-shrink: 0;" class="transition-transform group-hover:scale-105" />
            <div>
              <span class="font-serif text-2xl text-white group-hover:text-blue-300 transition-colors block">Healthcare Access Portal</span>
              <span class="block text-xs text-white/50 mt-0.5 font-sans">뉴저지 한인 의료 정보 포털</span>
            </div>
          </a>
          <p class="text-sm text-white/60 font-sans leading-relaxed max-w-xs mb-6">뉴저지 한인 커뮤니티를 위한 의료 접근 및 건강 정보 포털. 메디케어, ACA, 의료 상담을 한국어로 제공합니다.</p>
        </div>
        <div>
          <p class="text-xs font-sans font-semibold uppercase tracking-widest text-white/40 mb-4">정보</p>
          <ul class="space-y-2.5">
            <li><a class="text-sm font-sans text-white/60 hover:text-white transition-colors duration-200" href="/">홈</a></li>
            <li><a class="text-sm font-sans text-white/60 hover:text-white transition-colors duration-200" href="/about">소개</a></li>
            <li><a class="text-sm font-sans text-white/60 hover:text-white transition-colors duration-200" href="/blog">건강 뉴스</a></li>
          </ul>
        </div>
        <div>
          <p class="text-xs font-sans font-semibold uppercase tracking-widest text-white/40 mb-4">의료 가이드</p>
          <ul class="space-y-2.5">
            <li><a class="text-sm font-sans text-white/60 hover:text-white transition-colors duration-200" href="/medicare">메디케어 안내</a></li>
            <li><a class="text-sm font-sans text-white/60 hover:text-white transition-colors duration-200" href="/medicare#aca">ACA 보험</a></li>
            <li><a class="text-sm font-sans text-white/60 hover:text-white transition-colors duration-200" href="/medicare#faq">자주 묻는 질문</a></li>
          </ul>
        </div>
        <div>
          <p class="text-xs font-sans font-semibold uppercase tracking-widest text-white/40 mb-4">환자도우미</p>
          <ul class="space-y-2.5">
            <li><a class="text-sm font-sans text-white/60 hover:text-white transition-colors duration-200" href="/tool">보험 자격 진단</a></li>
            <li><a class="text-sm font-sans text-white/60 hover:text-white transition-colors duration-200" href="/tool">보조금 계산기</a></li>
            <li><a class="text-sm font-sans text-white/60 hover:text-white transition-colors duration-200" href="/tool">의학 용어 사전</a></li>
          </ul>
        </div>
      </div>
      <div class="border-t border-white/10 mt-12 pt-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div class="text-xs font-sans text-white/30 max-w-2xl leading-relaxed">
          <span class="font-semibold text-white/40">⚠ 의료 면책 조항:</span> 이 웹사이트의 정보는 교육 목적으로만 제공됩니다. 의료 결정은 반드시 자격을 갖춘 의료 전문가와 상담하십시오.
        </div>
        <p class="text-xs font-sans text-white/30 whitespace-nowrap">© 2026 Healthcare Access Portal</p>
      </div>
    </div>
  </footer>

  <script src="/js/cms-client.js?v=3.0.0"></script>
</body>
</html>
