<?php
/**
 * Global CMS Database & Cloud Configuration
 */

// Supabase Project Settings
define('SUPABASE_URL', 'https://hjswqohhrrgclosqsikw.supabase.co');
define('SUPABASE_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imhqc3dxb2hocnJnY2xvc3FzaWt3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODYzNjMxMTMsImV4cCI6MjEwMTkzOTExM30.cIaGtw9CSLvPib5V6WbB7nM5_AnGg0Iz_rd2ccO52UI');

// Local Fallback JSON Store
define('DATA_FILE', __DIR__ . '/../data/content.json');
