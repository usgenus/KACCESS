<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/supabase.php';

function get_supabase() {
    static $client = null;
    if ($client === null) {
        $client = new SupabaseClient(SUPABASE_URL, SUPABASE_KEY);
    }
    return $client;
}

function get_db_data($forceCloud = false) {
    // 1. Fast path: Read local cached content.json (< 1ms read)
    if (!$forceCloud && file_exists(DATA_FILE)) {
        clearstatcache(true, DATA_FILE);
        $content = @file_get_contents(DATA_FILE);
        if ($content) {
            $data = json_decode($content, true);
            if (is_array($data) && (!empty($data['posts']) || !empty($data['videos']) || !empty($data['billboards']))) {
                return $data;
            }
        }
    }

    // 2. Fallback / Cloud path: Query Supabase if local file is missing, empty, or sync requested
    $supabase = get_supabase();
    if ($supabase->isConfigured()) {
        try {
            $posts = $supabase->selectAll('posts', 'createdAt.desc') ?: [];
            $videos = $supabase->selectAll('videos', 'order.asc') ?: [];
            $billboards = $supabase->selectAll('billboards', 'order.asc') ?: [];
            $catRows = $supabase->selectAll('categories') ?: [];
            
            $categories = [
                'news' => ['전체', 'FDA 리콜', 'Health & Wellness', 'Medicare & ACA', '보건 정책 & 리포트', '병원 소식'],
                'videos' => ['전체', '심장 & 혈관', '뇌신경 질환', '암 예방 & 검진', '관절 & 정형외과', '만성질환 관리'],
                'billboards' => ['SPECIAL CAMPAIGN', 'MEDICARE UPDATE', 'PATIENT SUPPORT', 'HEALTH WEBINAR']
            ];
            foreach ($catRows as $row) {
                if (isset($row['type']) && isset($row['items'])) {
                    $categories[$row['type']] = is_array($row['items']) ? $row['items'] : json_decode($row['items'], true);
                }
            }

            // Normalize videos
            foreach ($videos as &$v) {
                if (!isset($v['doctor']) && isset($v['speaker'])) $v['doctor'] = $v['speaker'];
                if (!isset($v['thumbnail']) && isset($v['thumbnailUrl'])) $v['thumbnail'] = $v['thumbnailUrl'];
                if (!isset($v['summary']) && isset($v['description'])) $v['summary'] = $v['description'];
                if (!isset($v['youtubeId']) && isset($v['youtubeUrl'])) {
                    if (preg_match('~(?:youtu\.be/|youtube\.com/(?:embed/|v/|watch\?v=))([\w-]{11})~', $v['youtubeUrl'], $m)) {
                        $v['youtubeId'] = $m[1];
                    }
                }
            }

            $cloudData = [
                'billboards' => $billboards,
                'videos' => $videos,
                'posts' => $posts,
                'categories' => $categories
            ];

            // Cache to local JSON file for future instant reads
            $dir = dirname(DATA_FILE);
            if (!is_dir($dir)) {
                @mkdir($dir, 0777, true);
                @chmod($dir, 0777);
            }
            $json = json_encode($cloudData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            @file_put_contents(DATA_FILE, $json, LOCK_EX);
            @chmod(DATA_FILE, 0666);
            clearstatcache(true, DATA_FILE);

            return $cloudData;
        } catch (Exception $e) {
            error_log('Supabase read error: ' . $e->getMessage());
        }
    }

    if (!file_exists(DATA_FILE)) {
        return [
            'billboards' => [],
            'videos' => [],
            'posts' => [],
            'categories' => [
                'news' => ['전체', 'FDA 리콜', 'Health & Wellness', 'Medicare & ACA', '보건 정책 & 리포트', '병원 소식'],
                'videos' => ['전체', '심장 & 혈관', '뇌신경 질환', '암 예방 & 검진', '관절 & 정형외과', '만성질환 관리'],
                'billboards' => ['SPECIAL CAMPAIGN', 'MEDICARE UPDATE', 'PATIENT SUPPORT', 'HEALTH WEBINAR']
            ]
        ];
    }

    clearstatcache(true, DATA_FILE);
    $content = @file_get_contents(DATA_FILE);
    $data = json_decode($content, true);
    if (!$data || !is_array($data)) {
        return [
            'billboards' => [],
            'videos' => [],
            'posts' => [],
            'categories' => []
        ];
    }
    return $data;
}

function save_db_data($data) {
    // 1. Always save to local JSON file for speed & resilience
    $dir = dirname(DATA_FILE);
    if (!is_dir($dir)) {
        @mkdir($dir, 0777, true);
        @chmod($dir, 0777);
    }
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $res = file_put_contents(DATA_FILE, $json, LOCK_EX) !== false;
    @chmod(DATA_FILE, 0666);
    clearstatcache(true, DATA_FILE);

    // 2. Also sync to Supabase if configured
    $supabase = get_supabase();
    if ($supabase->isConfigured()) {
        try {
            if (!empty($data['posts'])) {
                foreach ($data['posts'] as $p) {
                    $row = [
                        'id' => $p['id'],
                        'slug' => !empty($p['slug']) ? $p['slug'] : $p['id'],
                        'title' => $p['title'] ?? '',
                        'category' => $p['category'] ?? 'Health & Wellness',
                        'date' => $p['date'] ?? date('Y-m-d'),
                        'isTopStory' => isset($p['isTopStory']) ? (bool)$p['isTopStory'] : false,
                        'isLiveUpdate' => isset($p['isLiveUpdate']) ? (bool)$p['isLiveUpdate'] : true,
                        'excerpt' => $p['excerpt'] ?? '',
                        'coverImage' => $p['coverImage'] ?? (!empty($p['images'][0]) ? $p['images'][0] : ''),
                        'images' => !empty($p['images']) ? (is_array($p['images']) ? array_values($p['images']) : [$p['images']]) : (!empty($p['coverImage']) ? [$p['coverImage']] : []),
                        'videoUrl' => $p['videoUrl'] ?? '',
                        'readTime' => $p['readTime'] ?? '3분',
                        'author' => $p['author'] ?? '편집부',
                        'content' => $p['content'] ?? '',
                        'summaryPoints' => !empty($p['summaryPoints']) ? (is_array($p['summaryPoints']) ? array_values($p['summaryPoints']) : explode("\n", $p['summaryPoints'])) : [],
                        'status' => $p['status'] ?? 'published'
                    ];
                    $supabase->upsert('posts', $row, 'id');
                }
            }
            if (!empty($data['videos'])) {
                foreach ($data['videos'] as $v) {
                    $row = [
                        'id' => $v['id'],
                        'title' => $v['title'] ?? '',
                        'speaker' => $v['doctor'] ?? ($v['speaker'] ?? ''),
                        'category' => $v['category'] ?? '만성질환 관리',
                        'date' => $v['date'] ?? date('Y.m.d'),
                        'duration' => $v['duration'] ?? '10:00',
                        'youtubeUrl' => $v['youtubeUrl'] ?? (!empty($v['youtubeId']) ? 'https://www.youtube.com/watch?v='.$v['youtubeId'] : ''),
                        'thumbnailUrl' => $v['thumbnail'] ?? ($v['thumbnailUrl'] ?? ''),
                        'videoFile' => $v['videoUrl'] ?? ($v['videoFile'] ?? ''),
                        'views' => $v['views'] ?? '1.2만회',
                        'description' => $v['summary'] ?? ($v['description'] ?? ''),
                        'order' => (int)($v['order'] ?? 1),
                        'active' => isset($v['active']) ? (bool)$v['active'] : true
                    ];
                    $supabase->upsert('videos', $row, 'id');
                }
            }
            if (!empty($data['billboards'])) {
                foreach ($data['billboards'] as $b) {
                    $supabase->upsert('billboards', $b, 'id');
                }
            }
            if (!empty($data['categories'])) {
                foreach ($data['categories'] as $type => $items) {
                    $supabase->upsert('categories', ['type' => $type, 'items' => $items], 'type');
                }
            }
        } catch (Exception $e) {
            error_log('Supabase sync error: ' . $e->getMessage());
        }
    }

    return $res;
}

function send_json($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: 0');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function require_auth() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    if (empty($_SESSION['cms_logged_in']) || $_SESSION['cms_logged_in'] !== true) {
        send_json(['success' => false, 'error' => '인증이 필요합니다. (Unauthorized)'], 401);
    }
}
