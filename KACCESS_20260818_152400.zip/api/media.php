<?php
/**
 * Healthcare Access Portal - Media Recovery & Serving Handler
 * Automatically recovers and serves uploaded media from persistent storage if disk cache is cleared.
 */

$file = $_GET['file'] ?? '';
$file = basename($file); // sanitize to filename only

if (empty($file)) {
    http_response_code(404);
    exit;
}

$ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
$mimeMap = [
    'jpg'  => 'image/jpeg',
    'jpeg' => 'image/jpeg',
    'png'  => 'image/png',
    'webp' => 'image/webp',
    'gif'  => 'image/gif',
    'svg'  => 'image/svg+xml',
    'mp4'  => 'video/mp4',
    'webm' => 'video/webm'
];
$mime = $mimeMap[$ext] ?? 'application/octet-stream';

$isImage = in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif', 'svg']);
$targetSubdir = $isImage ? 'images' : 'videos';
$diskPath = __DIR__ . '/../uploads/' . $targetSubdir . '/' . $file;

// 1. If physical file exists on disk, serve directly
if (file_exists($diskPath)) {
    header('Content-Type: ' . $mime);
    header('Cache-Control: public, max-age=31536000, immutable');
    header('Content-Length: ' . filesize($diskPath));
    readfile($diskPath);
    exit;
}

// 2. Try recovering from persistent media store (data/media_store.json)
$storeFile = __DIR__ . '/../data/media_store.json';
if (file_exists($storeFile)) {
    $store = json_decode(@file_get_contents($storeFile), true);
    if (is_array($store) && isset($store[$file])) {
        $entry = $store[$file];
        $rawBinary = null;
        if (is_string($entry)) {
            // Check if data URL or raw base64
            if (strpos($entry, 'base64,') !== false) {
                $rawBinary = base64_decode(explode('base64,', $entry)[1]);
            } else {
                $rawBinary = base64_decode($entry);
            }
        } elseif (is_array($entry) && !empty($entry['data'])) {
            $rawBinary = base64_decode(strpos($entry['data'], 'base64,') !== false ? explode('base64,', $entry['data'])[1] : $entry['data']);
        }

        if ($rawBinary) {
            // Re-write to disk for permanent high-speed static access
            $dir = dirname($diskPath);
            if (!is_dir($dir)) {
                @mkdir($dir, 0777, true);
            }
            @file_put_contents($diskPath, $rawBinary);

            header('Content-Type: ' . $mime);
            header('Cache-Control: public, max-age=31536000, immutable');
            header('Content-Length: ' . strlen($rawBinary));
            echo $rawBinary;
            exit;
        }
    }
}

// 3. Fallback for previously uploaded test images that are missing: redirect to standard medical stock photo
$fallbackUrl = 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=1200&q=80&auto=format';
header('Location: ' . $fallbackUrl, true, 302);
exit;
